from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('login/',views.login,name='loginadmin'),
    path('logout/',views.logout,name='logoutadmin'),
    path('register/',views.register,name='registeradmin'),
    path('dashboard/',views.dashboard,name='admin_dashboard'),
    path('add_flight/',views.add_flight,name='add_flight'),
    path('view_flight/',views.view_flight,name='view_flight'),
    path('delete_flight/<int:id>/',views.delete_flight,name='delete_flight'),
    path('update_flight/<int:id>/',views.update_flight,name='update_flight'),
]
