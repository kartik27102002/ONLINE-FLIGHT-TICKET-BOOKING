from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Admin_User(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    email = models.EmailField()
    phone = models.CharField(max_length=10)
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=50)    
    def __str__(self):
        return self.username


class Flight(models.Model):
    flight_name = models.CharField(max_length=50)
    # flight_no = models.IntegerField()
    source = models.CharField(max_length=50,default="",null=True)
    destination = models.CharField(max_length=50,default="",null=True)
    departure_time = models.CharField(max_length=50,default="",null=True)
    arrival_time = models.CharField(max_length=50,default="",null=True)
    # departure_time = models.TimeField()
    # arrival_time = models.TimeField()
    duration = models.CharField(max_length=50,default="",null=True)
    price = models.IntegerField(default=0,null=True)
    date = models.DateField(default="",null=True)
    seats = models.IntegerField(default=0,null=True)
    def __str__(self):
        return self.flight_name