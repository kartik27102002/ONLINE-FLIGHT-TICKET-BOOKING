from django.shortcuts import render
from django.shortcuts import redirect
from django.contrib import auth
from django.contrib.auth.decorators import login_required

#register admin
from django.contrib.auth.models import User
from .models import Admin_User,Flight
from django.contrib import messages
import datetime
from django.utils.dateparse import parse_date



def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        country = request.POST.get('country')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        print("input done")
        if password == confirm_password:
            try:
                user = User.objects.get(username=username)
                return render(request,'admin_accounts/register.html',context={'message':'username already exist'})
            except User.DoesNotExist:
                print("user does not exist")
                user = User.objects.create_user(username=username,email=email,password=password)
                admin_user = Admin_User.objects.create(user=user,email=email,phone=phone,address=address,city=city,state=state,country=country)
                # messages.success(request,'user created successfully')
                admin_user.save()
                print("user created successfully")
                return redirect('/admin_account/login/')
        else:
            return render(request,'admin_accounts/register.html',context={'message':'password not matched'})
    else:
        return render(request,'admin_accounts/register.html',context={'message':'first visit'})

# Create your views here.
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        print("input done")
        user = auth.authenticate(username=username,password=password)
        print("user authenticated")
        if user is not None:
            auth.login(request,user)
            print("login done")
            print("redirecting")
            return redirect('/admin_account/dashboard/')
        else:
            return render(request,'admin_accounts/login.html',context={'message':'user problem visit'})
    else:
        return render(request,'admin_accounts/login.html',context={'message':'first visit'})

# templates/admin_accounts/login.html
@login_required(login_url='/admin_account/login/')
def logout(request):
    auth.logout(request)
    return redirect('/admin_account/login/')

@login_required(login_url='/admin_account/login/')
def dashboard(request):
    flights = Flight.objects.all()
    return render(request,'dashboard_admin.html',context={'flights':flights})

@login_required(login_url='/admin_account/login/')
def add_flight(request):
    if request.method == 'POST':
        flight_name = request.POST.get('flight_name')
        # flight_no = int(request.POST.get('flight_no'))
        source = request.POST.get('source')
        destination = request.POST.get('destination')
        departure_time = request.POST.get('departure_time')
        arrival_time = request.POST.get('arrival_time')

        # duration = request.POST.get('duration')
        print(arrival_time)
        print(departure_time)
        arrival_time1 = arrival_time.split(':')
        departure_time1 = departure_time.split(':')
        print(arrival_time1)
        print(departure_time1)
        arrival_time1 = int(arrival_time1[0])*60 + int(arrival_time1[1])
        departure_time1 = int(departure_time1[0])*60 + int(departure_time1[1])
        print(arrival_time1)
        print(departure_time1)
        
        duration = arrival_time1 - departure_time1
        price = request.POST.get('price')
        date_str = request.POST.get('date')
        date = parse_date(date_str)
        seats = request.POST.get('seats')
        print("input done")
        print(type(flight_name))
        flight = Flight.objects.filter(flight_name=flight_name)
        if len(flight) != 0:
            print("flight exist")
            return render(request,'addflight.html',context={'message':'flight already exist'})
        else:
            print("flight does not exist")
            flight = Flight.objects.create(flight_name=flight_name,source=source,destination=destination,departure_time=departure_time,arrival_time=arrival_time,duration=duration,price=price,date=date,seats=seats,seat_available=seats)
            print("flight saved")
            flight.save()
            print("flight created successfully")
            return render(request,'addflight.html',context={'message':'flight created successfully'})
    else:
        return render(request,'addflight.html',context={})

@login_required(login_url='/admin_account/login/')
def view_flight(request):
    return render(request,'admin_account/view_flight.html',context={})

@login_required(login_url='/admin_account/login/')
def update_flight(request):
    return render(request,'admin_account/update_flight.html',context={})

@login_required(login_url='/admin_account/login/')
def delete_flight(request,id):
    flight = Flight.objects.get(id=id)
    flight.delete()
    return redirect('/admin_account/dashboard/')

