1. python -m virtualenv env
2. activate the environment according to your OS
3. pip install -r requirements.txt
4. python manage.py makemigrations
5. python manage.py migrate
6. python manage.py runserver
7.
