from django.db import models
from django.contrib.auth.models import User
from admin_account.models import Flight

# Create your models here.
class UserAccount(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    def __str__(self):
        return self.username
    
class Booking(models.Model):
    user = models.ForeignKey(UserAccount,on_delete=models.CASCADE)
    flight = models.ForeignKey(Flight,on_delete=models.CASCADE)
    booking_date = models.DateField(auto_now_add=True)
    booking_time = models.TimeField(auto_now_add=True)
    def __str__(self):
        return self.user.username