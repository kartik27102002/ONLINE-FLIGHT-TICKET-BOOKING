from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('login/',views.login,name='login'),
    path('register/',views.register,name='register'),
    path('logout/',views.logout,name='logout'),
    path('dashboard/',views.dashboard,name='dashboard'),
    # path('book_flight/',views.book_flight,name='book_flight'),
    path('book_flight/<int:flight_id>/',views.book_flight,name='book_flight'),
    # path('book_flight/<int:flight_id>/<int:seat_no>/',views.book_flight,name='book_flight'),
    path('show_bookings/',views.show_bookings,name='show_bookings'),
    # path('show_bookings/<int:booking_id>/',views.show_bookings,name='show_bookings'),
    # path('show_bookings/<int:booking_id>/<int:flight_id>/',views.show_bookings,name='show_bookings'),
    # path('search_flight/',views.search_flight,name='search_flight'),
    path('search_flight/<int:flight_id>/',views.search_flight,name='search_flight'),
]
