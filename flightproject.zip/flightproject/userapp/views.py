from django.shortcuts import render,redirect
from django.contrib import auth
from django.contrib.auth.decorators import login_required

#register admin
from django.contrib.auth.models import User
from userapp.models import UserAccount,Booking
from admin_account.models import Flight
from django.contrib import messages
import datetime
from django.utils.dateparse import parse_date


# Create your views here.
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        print("input done")
        user = auth.authenticate(username=username,password=password)
        print("user authenticated")
        if user is not None:
            auth.login(request,user)
            print("login done")
            print("redirecting")
            return redirect('/user/dashboard/')
        else:
            return render(request,'user_accounts/login.html',context={'message':'user problem visit'})
    else:
        return render(request,'user_accounts/login.html')

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        last_name  = request.POST.get('last_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        country = request.POST.get('country')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        print("input done")
        if password == confirm_password:
            try:
                print("user does not exist")
                user = User.objects.create_user(username=username,email=email,password=password,first_name=first_name,last_name=last_name)
                accuser = UserAccount.objects.create(user=user,email=email,phone=phone,address=address,city=city,state=state,country=country)
                # messages.success(request,'user created successfully')
                accuser.save()
                print("user created successfully")
                return redirect('/admin_account/login/')
                
            except:
                return render(request,'user_accounts/register.html',context={'message':'username already exist'})
        else:
            return render(request,'user_accounts/register.html',context={'message':'password not matched'})
    else:
        return render(request,'user_accounts/register.html',context={'message':'first visit'})

@login_required(login_url='/user/login/')
def dashboard(request):
    flight = Flight.objects.all()
    return render(request,'dashboard_user.html',context={'flights':flight})


@login_required(login_url='/user/login/')
def book_flight(request,flight_id):
    if request.method == 'POST':
        # flight_id = request.POST.get('flight_id')
        # seat_no = request.POST.get('seat_no')
        print(flight_id)
        # print(seat_no)
        if flight_id == '':
            return redirect('/user/dashboard/')
        try:
            # if 
            flight = Flight.objects.filter(id=flight_id)
            print(flight)
            if flight.seat_available > 0:
                return render(request,'book_flight.html',context={'message':'seat not available'})
            flight = Flight.objects.get(id=flight_id).update(seat_available=flight.seat_available-1)
            flight.save()
            usercc = UserAccount.objects.filter(user=User.objects.filter(username=request.user.username)[0]).first()
            booking = Booking.objects.create(user=usercc,flight=flight)
            booking.save()
            print("booking done")
            return redirect('/user/show_bookings/')
        except:
            return redirect('/user/dashboard/')
    else:
        return redirect('/user/dashboard/')


@login_required(login_url='/user/login/')
def show_bookings(request):
    usercc = User.objects.filter(username=request.user.username).first()
    user = UserAccount.objects.filter(user=usercc).first()
    booking = Booking.objects.filter(user=user).all()
    return render(request,'show_bookings.html',context={'bookings':booking})


def search_flight(request,flight_id):
    #search based on date and time
    if request.method == 'POST':
        date = request.POST.get('date')
        time = request.POST.get('time')
        date = datetime.datetime.strptime(date, "%Y-%m-%d").date()
        print(date)
        print(time)
        try:
            if date == '':
                flight = Flight.objects.filter(departure_time=time).all()
            elif  time == '':
                flight = Flight.objects.filter(date=date).all()
            else:
                flight = Flight.objects.filter(date=date,departure_time=time).all()
            for i in flight:
                print(i)
                
            return render(request,'dashboard_user.html',context={'flight':flight})
        except:
            return render(request,'dashboard_user.html',context={'message':'flight not found'})
    else:
        return render(request,'dashboard_user.html')

@login_required(login_url='/user/login/')
def logout(request):
    auth.logout(request)
    print("logout done")
    return redirect('/user/login/')





# <!-- <form method="post" action="{% url 'search_flight' %}">
#         {% csrf_token %}
#         <input type="date" name="date" placeholder="Departure Date">
#         <input type="time" name="time" placeholder="Departure Time">
#         <input type="submit" value="Search">
#     </form>
#     {{message}} -->